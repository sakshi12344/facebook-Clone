# Figma-Project
HTML and CSS  have been used in this tiny project
![Screenshot from 2022-10-08 06-53-51](https://user-images.githubusercontent.com/98875003/194680782-8552891c-7e2c-4d17-8bc4-b9bd46df7861.png)
![Screenshot from 2022-10-08 06-54-03](https://user-images.githubusercontent.com/98875003/194680791-4b2c1c94-1e03-456e-b910-91d067d5ec33.png)
![Screenshot from 2022-10-08 06-54-14](https://user-images.githubusercontent.com/98875003/194680794-b1154ff5-a1f2-43eb-88da-2e124a3ed3e6.png)
